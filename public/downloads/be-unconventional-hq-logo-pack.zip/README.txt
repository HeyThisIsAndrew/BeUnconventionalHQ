Be Unconventional HQ - Logo Pack (starter)
============================================

Contents:
- be-unconventional-hq-logo.webp   Primary wordmark lockup (as used site-wide)
- be-unconventional-hq-mark.svg    Vector brand mark, scales to any size
- be-unconventional-hq-icon.ico    Multi-resolution icon (16x16 / 32x32)

This is a starter pack built from the assets already in production use on
beunconventionalhq.com - not a full press kit (no reversed/white variant,
no transparent-background PNG exports, no horizontal lockup). If you need
a specific format or color variant for a sponsor deck or press wall,
email press@beunconventionalhq.com.

(c) Be Unconventional HQ. For editorial and partner use.
